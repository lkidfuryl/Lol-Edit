﻿#if !__cplusplus
namespace LolEdit
{
    static class Version
    {
        public const string VERSION =
#endif
        "1.0"
#if !__cplusplus
        ;
        public const int BUILD_NUMBER = 2000;
    }
}
#endif