﻿using System;
using System.Windows;
using System.Windows.Interop;
using ModernWpf;
using LolEdit.Main;

namespace LolEdit
{
    public partial class MainWindow : Window
    {
        public static MainWindow Instance { get; private set; }

        public MainWindow()
        {
            Instance = this;
            InitializeComponent();
            ConfigureWindow();
            InitializeButtons();
            Loaded += OnMainWindowLoaded;
            SourceInitialized += InitializeWindowHook;
        }

        private void ConfigureWindow()
        {
            WindowStyle = WindowStyle.ToolWindow;
            ShowInTaskbar = true;

            btnPlugins.Content = $"Abrir Plugins ({Plugins.CountEntries()})";
            txtVersion.Text = $"v{Version.VERSION}.{Version.BUILD_NUMBER}";
        }

        private void InitializeButtons()
        {
            btnGitHub.Click += (sender, args) => Utils.OpenLink(Program.GithubUrl);
            btnHomepage.Click += (sender, args) => Utils.OpenLink(Program.HomepageUrl);
            btnPlugins.Click += BtnPlugins_Click;
            btnActivate.Toggled += BtnActivate_Toggled;
        }

        private void OnMainWindowLoaded(object sender, RoutedEventArgs e)
        {
            Loaded -= OnMainWindowLoaded;
            UpdateActiveState();
            Show();
            var hwnd = new WindowInteropHelper(this).Handle;
            var oldEx = Native.GetWindowLongPtr(hwnd, -0x14).ToInt32();
            Native.SetWindowLongPtr(hwnd, -0x14, (IntPtr)(oldEx & ~0x80));

            Updater.CheckUpdate();
        }
        private void BtnTheme_Click(object sender, RoutedEventArgs e)
        {
            var tm = ThemeManager.Current;
            var isLight = tm.ApplicationTheme == null
                ? tm.ActualApplicationTheme == ApplicationTheme.Light
                : tm.ApplicationTheme == ApplicationTheme.Light;
            tm.ApplicationTheme = isLight
                ? ApplicationTheme.Dark
                : ApplicationTheme.Light;
        }
        private void BtnPlugins_Click(object sender, RoutedEventArgs e) => Utils.OpenFolder(Config.PluginsDir);
        private void BtnActivate_Toggled(object sender, RoutedEventArgs e)
        {
            try
            {
                ToggleActivation();
            }
            catch (Exception ex)
            {
                var message = $"Hubo un error.\nError: {ex.Message}\n\nCaptura el error y mencionelo";
                var result = ShowMessage(message, Program.Name, MessageBoxImage.Warning, MessageBoxButton.YesNo);

                if (result == MessageBoxResult.Yes)
                {
                    Utils.OpenLink(Program.GithubIssuesUrl);
                }
            }
            finally
            {
                UpdateActiveState();
            }
        }
        private void ToggleActivation()
        {
            if (!Module.IsActivated())
            {
                if (!Module.Exists())
                {
                    ShowMessage("Fallo el cargar core.dll", Program.Name, MessageBoxImage.Error);
                }
                else if (Module.Activate())
                {
                    PromptRestart("Activado correctamente.", false);
                }
                else
                {
                    ShowMessage("Error al activar", Program.Name, MessageBoxImage.Error);
                }
            }
            else
            {
                Module.Deactivate();
                PromptRestart("Desactivado correctamente", true);
            }
        }
        private MessageBoxResult ShowMessage(string message, string caption, MessageBoxImage icon, MessageBoxButton button = MessageBoxButton.OK)
            => icon == MessageBoxImage.Question
                ? MessageBox.Show(this, message, caption, MessageBoxButton.YesNo, icon)
                : MessageBox.Show(this, message, caption, MessageBoxButton.OK, icon);
        private void PromptRestart(string message, bool isDeactivaed)
        {
            if ((LCU.IsRunning() && !isDeactivaed) || (Module.IsLoaded() && isDeactivaed))
            {
                if (MessageBox.Show(this, "¿Reiniciar Cliente de Lol?",
                    Program.Name, MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    LCU.KillUxAndRestart();
                    ShowMessage(message, Program.Name, MessageBoxImage.Information);
                }
            }
            else
            {
                ShowMessage(message, Program.Name, MessageBoxImage.Information);
            }
        }
        void UpdateActiveState()
        {
            btnActivate.Toggled -= BtnActivate_Toggled;
            btnActivate.IsOn = Module.IsActivated();
            btnActivate.Toggled += BtnActivate_Toggled;
        }
        private void InitializeWindowHook(object sender, EventArgs e)
        {
            var source = HwndSource.FromHwnd(new WindowInteropHelper(this).Handle);
            source.AddHook(new HwndSourceHook(WndProc));
        }
        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wp, IntPtr lp, ref bool handled)
        {
            if (msg == Native.WM_SHOWME)
            {
                if (WindowState == WindowState.Minimized)
                {
                    WindowState = WindowState.Normal;
                }
                if (!IsVisible)
                {
                    Show();
                }
                Activate();
                handled = true;
            }
            return IntPtr.Zero;
        }
        private void Entrenamiento_Click(object sender, RoutedEventArgs e)
        {
            string path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "porolobby.exe");
            System.Diagnostics.Process.Start(path);
        }
    }
}